package com.asz.rubik;

public class RubikCubePieceFace {
	private RubikCubeSide side;

	public RubikCubePieceFace(RubikCubeSide sideType) {
		this.side = sideType;
	}
	
	public int getTypeCode() {
		return side.getTypeCode();
	}

	public RubikCubeSide getSide() {
		return this.side;
	}
}
