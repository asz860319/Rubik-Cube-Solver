package com.asz.rubik;

public abstract class RubikCubePiece {
	RubikCube cube;
	protected RubikCubePieceFace face1;

	public RubikCube getCube() {
		return cube;
	}

	public RubikCubePieceFace getFace1() {
		return face1;
	}

	public abstract RubikCubePieceFace getFaceOn(RubikCubeSide side);
}
