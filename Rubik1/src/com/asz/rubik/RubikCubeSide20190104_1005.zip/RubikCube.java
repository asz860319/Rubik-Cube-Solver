package com.asz.rubik;

import java.util.ArrayList;
import java.util.HashMap;

public class RubikCube {
		
	private static HashMap<Integer, Integer> staticSidesOrderTable;

	private ArrayList<RubikCubeSide> sides;
	private ArrayList<RubikCubeEdge> edges;
	private ArrayList<RubikCubeCorner> corners;

	private RubikCubeHistory history = new RubikCubeHistory(this);

	
	public RubikCube() 
	{
		this.initialize();
	}
	
	private void initialize() 
	{
		sides = new ArrayList<RubikCubeSide>();
		edges = new ArrayList<RubikCubeEdge>();
		corners = new ArrayList<RubikCubeCorner>();

		for(int lop = 0; lop < 6; lop++)
		{
			sides.add(new RubikCubeSide(this, lop));
		}		
		
		for(int lop = 0; lop < 6; lop++)
		{
			RubikCubeSide side=getSide(lop);
			ArrayList<RubikCubeSide> adjacentSides = side.getAdjacentSidesOrdered();
			
			for(int i = 0; i < adjacentSides.size(); i++)
			{
				RubikCubeSide adj=adjacentSides.get(i);
				
				if(getEdgePieceByFace(side, adj) == null)
				{
					edges.add(new RubikCubeEdge(this, side, adj));
				}
			}
		}	
		
		ArrayList<RubikCubeSide> adjacentSides = getSide(0).getAdjacentSidesOrdered();

		for(int lop = 0; lop < adjacentSides.size(); lop++)
		{
			corners.add(new RubikCubeCorner(
					this, 
					getSide(0), 
					adjacentSides.get(lop), 
					calculateLeft(
						getSide(0), 
						adjacentSides.get(lop)))
					);
			
			corners.add(new RubikCubeCorner(
					this, 
					getSide(0).getOppositeSide(), 
					adjacentSides.get(lop), 
					calculateLeft(
						getSide(0).getOppositeSide(), 
						adjacentSides.get(lop)))
					);
		}
	}
	
	public ArrayList<RubikCubeSide> getSides() {
		return sides;
	}

	public RubikCubeSide getSide(int sideCode) {
		return sides.get(sideCode);
	}
	
	public RubikCubeSide calculateLeft(RubikCubeSide side_up, RubikCubeSide side_front) 
	{				
		return getSide(getSidesOrder().get(side_up.getTypeCode() * 6 + side_front.getTypeCode()));
	}
	
	private HashMap<Integer, Integer> getSidesOrder() 
	{
		if(staticSidesOrderTable == null)
		{
			staticSidesOrderTable = new HashMap<Integer, Integer>();

			addFinalItemsToArray(1, 5, 2);
		}
		return staticSidesOrderTable;
	}

	private void addFinalItemsToArray(int up, int front, int left) 
{		
		addSetsItemsToArray(up, front, left);
		addSetsItemsToArray(5 - left, up, 5 - front);	
		addSetsItemsToArray(front, 5 - left, 5 - up);
	}

	private void addSetsItemsToArray(int up, int front, int left) {
		addItemsToArray(up, front, left);
		addItemsToArray(left, up, front);
	}

	private void addItemsToArray(int up, int front, int left) 
	{
		staticSidesOrderTable.put(up * 6 + front, left);
		staticSidesOrderTable.put(up * 6 + left, getSide(front).getOppositeSide().getTypeCode());
		staticSidesOrderTable.put(up * 6 + getSide(front).getOppositeSide().getTypeCode(), 
				getSide(left).getOppositeSide().getTypeCode());
		staticSidesOrderTable.put(up * 6 + getSide(left).getOppositeSide().getTypeCode(), front);
	}
	
	public void moveClockwise(RubikCubeSide side) throws Exception {
		moveClockwise(side, 1);
	}
	
	public void moveClockwise(RubikCubeSide side, int count) throws Exception
	{
		moveClockwise(side, count, true);
	}
	
	void moveClockwise(RubikCubeSide side, int count, boolean saveHistory) throws Exception 
	{
		if(saveHistory)
		{
			history.addToHistory(side, count);
		}
		
		for(int i = 0; i < count; i++)
		{
			movePiecesClockwise(side);
		}
	}
	
	private void movePiecesClockwise(RubikCubeSide side) throws Exception 
	{		
		ArrayList<RubikCubeSide> adjacentSides = side.getAdjacentSidesOrderedReverse();
		
		//Ring for edges
		ArrayList<RubikCubeEdge> ringEdge = new ArrayList<RubikCubeEdge>();

		for(int lop = 0; lop < adjacentSides.size(); lop++)
		{
			ringEdge.add(getEdgePieceByLocation(side, adjacentSides.get(lop)));
		}
//		for(int lop=0; lop<ringEdge.size(); lop++) {
//			RubikCubeEdge r = ringEdge.get(lop);
//			System.out.println(
//					"" +
//					r.getFace1().getTypeCode() +
//					r.getFace2().getTypeCode() +
//					r.getLocation1().getTypeCode() +
//					r.getLocation2().getTypeCode());
//		}
		crossSideEdgeRotation(side, ringEdge);
//		for(int lop=0; lop<ringEdge.size(); lop++) {
//			RubikCubeEdge r = ringEdge.get(lop);
//			System.out.println(
//					"" +
//					r.getFace1().getTypeCode() +
//					r.getFace2().getTypeCode() +
//					r.getLocation1().getTypeCode() +
//					r.getLocation2().getTypeCode());
//		}
		//Ring for corners
		ArrayList<RubikCubeCorner> ringCorner = new ArrayList<RubikCubeCorner>();
		
		for(int lop = 0; lop < adjacentSides.size(); lop++)
		{
			ringCorner.add(
				getCornerPieceByLocation(
					side, 
					adjacentSides.get(lop), 
					calculateLeft(side, adjacentSides.get(lop))
					)
				);
		}
		crossSideCornerRotation(side, ringCorner);
	}

	private void crossSideCornerRotation(RubikCubeSide side, ArrayList<RubikCubeCorner> ring) 
	{
		RubikCubeSide swapPlace1 = ring.get(0).getLocation1();
		RubikCubeSide swapPlace2 = ring.get(0).getLocation2();
		RubikCubeSide swapPlace3 = ring.get(0).getLocation3();

		for(int lop = 0; lop < ring.size(); lop++)
		{
			RubikCubeSide targetPlace1;
			RubikCubeSide targetPlace2;
			RubikCubeSide targetPlace3;

			RubikCubeCorner movingCorner = ring.get(lop);
		
			if(lop == ring.size() - 1)
			{
				targetPlace1 = swapPlace1;
				targetPlace2 = swapPlace2;
				targetPlace3 = swapPlace3;
			} else 
			{
				targetPlace1 = ring.get(lop + 1).getLocation1();
				targetPlace2 = ring.get(lop + 1).getLocation2();
				targetPlace3 = ring.get(lop + 1).getLocation3();
			}

			movingCorner.setLocationWithOneSideRotation(side, targetPlace1, targetPlace2, targetPlace3);
		}
	}

	private void crossSideEdgeRotation(RubikCubeSide side, ArrayList<RubikCubeEdge> ring) 
	{
		RubikCubeSide swapPlace1 = ring.get(0).getLocation1();
		RubikCubeSide swapPlace2 = ring.get(0).getLocation2();
		
		for(int lop = 0; lop < ring.size(); lop++)
		{
			RubikCubeSide targetPlace1;
			RubikCubeSide targetPlace2;

			RubikCubeEdge movingEdge = ring.get(lop);
		
			if(lop == ring.size() - 1)
			{
				targetPlace1 = swapPlace1;
				targetPlace2 = swapPlace2;
			} else 
			{
				targetPlace1 = ring.get(lop+1).getLocation1();
				targetPlace2 = ring.get(lop+1).getLocation2();
			}
		
			movingEdge.setLocationWithOneSideRotation(side, targetPlace1, targetPlace2);
		}
	}

	public void moveCounterClockwise(RubikCubeSide side) throws Exception {
		moveCounterClockwise(side, 1);
	}
	
	public void moveCounterClockwise(RubikCubeSide side, int count) throws Exception {
		moveClockwise(side, count * 3, true);
	}
	
	void moveCounterClockwise(RubikCubeSide side, int count, boolean saveHistory) throws Exception {
		if(saveHistory)
		{
			history.addToHistory(side, -count);
		}
		moveClockwise(side, count * 3, false);
	}

	public void undoLastMoves(int i) throws Exception {
		history.undoLastMoves(i);
	}

	public void redoMoves(int i) throws Exception {
		history.redoMoves(i);
	}
	

	public RubikCubeEdge getEdgePieceByLocation(RubikCubeSide locationSide1, RubikCubeSide locationSide2)  
	{
		for(int lop = 0; lop < edges.size(); lop++)
		{
			if(
				(edges.get(lop).getLocation1() == locationSide1
					&& edges.get(lop).getLocation2() == locationSide2)
			||
				( edges.get(lop).getLocation1() == locationSide2
					&& edges.get(lop).getLocation2() == locationSide1)
				)
			{
				return edges.get(lop);
			}
		}
		return null;
	}
	
	public RubikCubeCorner getCornerPieceByLocation(RubikCubeSide locationSide1, RubikCubeSide locationSide2,
			RubikCubeSide locationSide3) 
	{
		for(int lop = 0; lop < corners.size(); lop++)
		{
			if(corners.get(lop).doesLocationMatch(locationSide1, locationSide2, locationSide3))
			{
				return corners.get(lop);
			}
		}

		return null;
	}
	
	public RubikCubeEdge getEdgePieceByFace(RubikCubeSide side1, RubikCubeSide side2)
	{
		for(int lop = 0; lop < edges.size(); lop++)
		{
			if(edges.get(lop).hasSameSides(side1, side2))
			{
				return edges.get(lop);
			}
		}
		return null;
	}
}
