package com.asz.rubik;

public class RubikCubePieceFace {
	private RubikCubeSide sideType;

	public RubikCubePieceFace(RubikCubeSide sideType) {
		this.sideType = sideType;
	}
	
	public int getTypeCode() {
		return sideType.getTypeCode();
	}

	public RubikCubeSide getFace() {
		return this.sideType;
	}
}
