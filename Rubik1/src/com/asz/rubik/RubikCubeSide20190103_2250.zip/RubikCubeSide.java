package com.asz.rubik;

import java.util.ArrayList;
import java.util.Collections;

public class RubikCubeSide 
{
	private int sideCode;

	private ArrayList<PieceFace> pieceFaces;

	private final RubikCube myCube;
	
	public RubikCubeSide(RubikCube myCube, int sideCode) 
	{
		this.myCube = myCube;
		this.sideCode = sideCode;
		this.initialize();
	}

	public void initialize() 
	{
		pieceFaces = new ArrayList<PieceFace>();
		
		for(int lop = 0; lop < 9; lop++)
		{
			pieceFaces.add(new PieceFace(lop, sideCode));
		}
	}
	
	public RubikCubeSide getOppositeSide()
	{
		return myCube.getSide(5 - sideCode);
	}
	
	private ArrayList<RubikCubeSide> getAdjacentSides() {
		
		ArrayList<RubikCubeSide> ret = new ArrayList<RubikCubeSide>();
		
		for(int lop = 0; lop < myCube.getSides().size(); lop++)
		{
			if(myCube.getSides().get(lop).getSideCode() != sideCode && 
					myCube.getSides().get(lop) != 
						myCube.getSide(sideCode).getOppositeSide())
			{
				ret.add(myCube.getSides().get(lop));
			}
		}	
		
		return ret;
	}

	public PieceFace getPieceFace(int location) {
		return pieceFaces.get(location);
	}
	
	public int getSideCode() {
		return sideCode;
	}
	
	public void rotationReplacement(Integer[] ring)
	{
		int placeHolder = this.getPieceFace(ring[0]).getSideCode();

		for(int lop = 0; lop < ring.length; lop++)
		{
			if(lop < ring.length - 1)
			{
				this.getPieceFace(ring[lop]).setSideCode(
						this.getPieceFace(ring[lop + 1]).getSideCode());
			} else
			{
				this.getPieceFace(ring[lop]).setSideCode(placeHolder);
			}
		}
	}

	public ArrayList<RubikCubeSide> getAdjacentSidesOrdered() {
		ArrayList<RubikCubeSide> ret = new ArrayList<>();
		
		RubikCubeSide s0 = this.getAdjacentSides().get(0);
		RubikCubeSide s3 = myCube.calculateLeft(this, s0);
		
		RubikCubeSide s1 = s3.getOppositeSide();
		RubikCubeSide s2 = s0.getOppositeSide();
		
		ret.add(s0);
		ret.add(s1);
		ret.add(s2);
		ret.add(s3);

		return ret;
	}
	
	public void moveSidePiecesOnlyClockWise() 
	{		
		Integer[] ring;
		
		ring = new Integer[] {6, 8, 2, 0};
		this.rotationReplacement(ring);
		
		ring = new Integer[] {3, 7, 5, 1};		
		this.rotationReplacement(ring);
	}

	public int getCompassFor(RubikCubeSide sideDirectionUnkown) throws Exception 
	{
		int ret = -1;
		
		//Found north of sideCodeMain from list,
		RubikCubeSide north = this.getNorthSide();
		//Found south of sideCodeMain,
		RubikCubeSide south = north.getOppositeSide();
		//Found east of sideCodeMain,
		RubikCubeSide east = myCube.calculateLeft(this, north);
		//Found west of SideCodeMain.
		RubikCubeSide west = east.getOppositeSide();
		//Find which of these 4 are sideCodeDirectionUnkown
				
		if(sideDirectionUnkown == north)
		{
			ret = 1;
		} else if(sideDirectionUnkown == west)
		{
			ret = 3;
		} else if(sideDirectionUnkown == south)
		{
			ret = 7;
		} else if(sideDirectionUnkown == east)
		{
			ret = 5;
		} else {
			System.out.println("ERROR");
		}
		
		return ret;
	}

	public RubikCubeEdge getEdgePieceByLocation(Integer locationCode) 
	{
		RubikCubeSide otherSide = getSideAtEdgeLocation(locationCode);
		
		return myCube.getEdgePieceByLocation(this, otherSide);
	}

	public RubikCubeCorner getCornerPieceByLocation(Integer locationCode) 
	{
		ArrayList<RubikCubeSide> otherSides = getSidesAtCornerLocation(locationCode);

		return myCube.getCornerPieceByLocation(this, otherSides.get(0), otherSides.get(1));
	}
	
	private ArrayList<RubikCubeSide> getSidesAtCornerLocation(Integer locationCode) {
		ArrayList<RubikCubeSide> ret=new ArrayList<RubikCubeSide>();
		
		switch(locationCode)
		{
		case 0:
			ret.add(getNorthSide());
			ret.add(getWestSide());
			break;
		case 2:
			ret.add(getNorthSide());
			ret.add(getEastSide());
			break;
		case 6:
			ret.add(getSouthSide());
			ret.add(getWestSide());
			break;
		case 8:
			ret.add(getSouthSide());
			ret.add(getEastSide());
			break;
		default:
			ret = null;
		}

		return ret;
	}

	private RubikCubeSide getSideAtEdgeLocation(Integer locationCode) {
		RubikCubeSide ret;
		
		switch(locationCode)
		{
		case 1:
			ret = getNorthSide();
			break;
		case 3:
			ret = getWestSide();
			break;
		case 5:
			ret = getEastSide();
			break;
		case 7:
			ret = getSouthSide();
			break;
		default:
			ret = null;
		}
		
		return ret;
	}
	
	private RubikCubeSide getSouthSide() {
		return getNorthSide().getOppositeSide();
	}

	private RubikCubeSide getEastSide() {
		return getWestSide().getOppositeSide();
	}

	private RubikCubeSide getWestSide() {
		return myCube.calculateLeft(getNorthSide(), this);
	}

	private RubikCubeSide getNorthSide() {
		int northSideCode;		
		
		switch(sideCode) {
		case 0:
			northSideCode = 2;
			break;
		case 1:
			northSideCode = 3;
			break;
		case 2:
			northSideCode = 4;
			break;
		case 3:
			northSideCode = 5;
			break;
		case 4:
			northSideCode = 0;
			break;
		case 5:
			northSideCode = 1;
			break;
		default:
			northSideCode = -1;
		}		
		
		return myCube.getSide(northSideCode);
	}

	public ArrayList<RubikCubeSide> getAdjacentSidesOrderedReverse() {
		ArrayList<RubikCubeSide> ret = getAdjacentSidesOrdered();
		Collections.reverse(ret);
		return ret;
	}
}
