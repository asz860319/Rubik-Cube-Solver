package com.asz.rubik;

public class PieceFace {

	private int sideCode;
	private int locationCode;

	public PieceFace(int locationCode, int sideCode) {
		this.locationCode = locationCode;
		this.sideCode = sideCode;
	}
	
	public int getSideCode() {
		return sideCode;
	}
	
	public int getLocationCode() {
		return locationCode;
	}
	
	public void setSideCode(int sideCode) {
		this.sideCode = sideCode;
	}	
}
