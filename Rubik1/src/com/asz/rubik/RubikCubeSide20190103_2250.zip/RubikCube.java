package com.asz.rubik;

import java.util.ArrayList;
import java.util.HashMap;

public class RubikCube {
		
	private static HashMap<Integer, Integer> staticSidesOrderTable;

	private ArrayList<RubikCubeSide> sides;
	private ArrayList<RubikCubeEdge> edges;
	private ArrayList<RubikCubeCorner> corners;

	private RubikCubeHistory history = new RubikCubeHistory(this);

	
	public RubikCube() 
	{
		this.initialize();
	}
	
	private void initialize() 
	{
		sides = new ArrayList<RubikCubeSide>();
		edges = new ArrayList<RubikCubeEdge>();
		corners = new ArrayList<RubikCubeCorner>();

		for(int lop = 0; lop < 6; lop++)
		{
			sides.add(new RubikCubeSide(this, lop));
		}		
		
		for(int lop = 0; lop < 6; lop++)
		{
			ArrayList<RubikCubeSide> adjacentSides = getSide(lop).getAdjacentSidesOrdered();
			
			for(int i = 0; i < adjacentSides.size(); i++)
			{
				if(getEdgePieceByFace(getSide(lop), adjacentSides.get(i)) == null)
				{
					edges.add(new RubikCubeEdge(this, getSide(lop), adjacentSides.get(i)));
				}
			}
		}	
		
		ArrayList<RubikCubeSide> adjacentSides = getSide(0).getAdjacentSidesOrdered();

		for(int lop = 0; lop < adjacentSides.size(); lop++)
		{
			corners.add(new RubikCubeCorner(
					this, 
					getSide(0), 
					adjacentSides.get(lop), 
					calculateLeft(
						getSide(0), 
						adjacentSides.get(lop)))
					);
			
			corners.add(new RubikCubeCorner(
					this, 
					getSide(0).getOppositeSide(), 
					adjacentSides.get(lop), 
					calculateLeft(
						getSide(0).getOppositeSide(), 
						adjacentSides.get(lop)))
					);
		}
	}
	
	public ArrayList<RubikCubeSide> getSides() {
		return sides;
	}

	public RubikCubeSide getSide(int sideCode) {
		return sides.get(sideCode);
	}
	
	public RubikCubeSide calculateLeft(RubikCubeSide side_up, RubikCubeSide side_front) 
	{				
		return getSide(getSidesOrder().get(side_up.getSideCode() * 6 + side_front.getSideCode()));
	}
	
	private HashMap<Integer, Integer> getSidesOrder() 
	{
		if(staticSidesOrderTable == null)
		{
			staticSidesOrderTable = new HashMap<Integer, Integer>();

			addFinalItemsToArray(1, 5, 2);
		}
		return staticSidesOrderTable;
	}

	private void addFinalItemsToArray(int up, int front, int left) 
{		
		addSetsItemsToArray(up, front, left);
		addSetsItemsToArray(5 - left, up, 5 - front);	
		addSetsItemsToArray(front, 5 - left, 5 - up);
	}

	private void addSetsItemsToArray(int up, int front, int left) {
		addItemsToArray(up, front, left);
		addItemsToArray(left, up, front);
	}

	private void addItemsToArray(int up, int front, int left) 
	{
		staticSidesOrderTable.put(up * 6 + front, left);
		staticSidesOrderTable.put(up * 6 + left, getSide(front).getOppositeSide().getSideCode());
		staticSidesOrderTable.put(up * 6 + getSide(front).getOppositeSide().getSideCode(), 
				getSide(left).getOppositeSide().getSideCode());
		staticSidesOrderTable.put(up * 6 + getSide(left).getOppositeSide().getSideCode(), front);
	}
	
	public void moveClockwise(RubikCubeSide side) throws Exception {
		moveClockwise(side, 1);
	}
	
	public void moveClockwise(RubikCubeSide side, int count) throws Exception
	{
		moveClockwise(side, count, true);
	}
	
	void moveClockwise(RubikCubeSide side, int count, boolean saveHistory) throws Exception 
	{
		if(saveHistory)
		{
			history.addToHistory(side, count);
		}
		
		for(int i = 0; i < count; i++)
		{
			movePieceFacesClockwise(side);
			movePiecesClockwise(side);
		}
	}
	
	private void movePiecesClockwise(RubikCubeSide side) throws Exception 
	{		
		ArrayList<RubikCubeSide> adjacentSides = side.getAdjacentSidesOrderedReverse();
		
		//Ring for edges
		ArrayList<RubikCubeEdge> ringEdge = new ArrayList<RubikCubeEdge>();

		for(int lop = 0; lop < adjacentSides.size(); lop++)
		{
			ringEdge.add(getEdgePieceByLocation(side, adjacentSides.get(lop)));
		}
		crossSideEdgeRotation(side, ringEdge);
		
		//Ring for corners
		ArrayList<RubikCubeCorner> ringCorner = new ArrayList<RubikCubeCorner>();
		
		for(int lop = 0; lop < adjacentSides.size(); lop++)
		{
			ringCorner.add(
				getCornerPieceByLocation(
					side, 
					adjacentSides.get(lop), 
					calculateLeft(side, adjacentSides.get(lop))
					)
				);
		}
		crossSideCornerRotation(side, ringCorner);
	}

	private void crossSideCornerRotation(RubikCubeSide side, ArrayList<RubikCubeCorner> ring) 
	{
		RubikCubeSide swapPlace1 = ring.get(0).getLocation1();
		RubikCubeSide swapPlace2 = ring.get(0).getLocation2();
		RubikCubeSide swapPlace3 = ring.get(0).getLocation3();

		for(int lop = 0; lop < ring.size(); lop++)
		{
			RubikCubeSide targetPlace1;
			RubikCubeSide targetPlace2;
			RubikCubeSide targetPlace3;

			RubikCubeCorner movingCorner = ring.get(lop);
		
			if(lop == ring.size() - 1)
			{
				targetPlace1 = swapPlace1;
				targetPlace2 = swapPlace2;
				targetPlace3 = swapPlace3;
			} else 
			{
				targetPlace1 = ring.get(lop + 1).getLocation1();
				targetPlace2 = ring.get(lop + 1).getLocation2();
				targetPlace3 = ring.get(lop + 1).getLocation3();
			}

			movingCorner.setLocationWithOneSideRotation(side, targetPlace1, targetPlace2, targetPlace3);
		}
	}

	private void crossSideEdgeRotation(RubikCubeSide side, ArrayList<RubikCubeEdge> ring) 
	{
		RubikCubeSide swapPlace1 = ring.get(0).getLocation1();
		RubikCubeSide swapPlace2 = ring.get(0).getLocation2();
		
		for(int lop = 0; lop < ring.size(); lop++)
		{
			RubikCubeSide targetPlace1;
			RubikCubeSide targetPlace2;

			RubikCubeEdge movingEdge = ring.get(lop);
		
			if(lop == ring.size() - 1)
			{
				targetPlace1 = swapPlace1;
				targetPlace2 = swapPlace2;
			} else 
			{
				targetPlace1 = ring.get(lop+1).getLocation1();
				targetPlace2 = ring.get(lop+1).getLocation2();
			}
		
			if((targetPlace1 == side) != (movingEdge.getLocation1() == side)) 
			{
				RubikCubeSide targetPlaceT = targetPlace1;
				targetPlace1 = targetPlace2;
				targetPlace2 = targetPlaceT;
			}

			movingEdge.setLocation(targetPlace1, targetPlace2);
		}
	}

	private void movePieceFacesClockwise(RubikCubeSide side) throws Exception 
	{
		side.moveSidePiecesOnlyClockWise();
		
		ArrayList<RubikCubeSide> adjacentSides = side.getAdjacentSidesOrdered();
		ArrayList<Integer> ring;

		for(int ringID = 0; ringID < 3; ringID++)
		{
			ring = new ArrayList<Integer>();
			for(int lop = 0; lop < adjacentSides.size(); lop++)
			{
				ring.add(adjacentSides.get(lop).getSideCode() * 9 + 
						getRotationTarget(side, adjacentSides.get(lop), ringID));
			}
			crossSidePieceFaceRotation(ring);
		}			
	}

	private int getRotationTarget(RubikCubeSide sideRotating, 
			RubikCubeSide sideAdjacent, int whichPieceFace) throws Exception
	{
		int ret = -1;
		int compassForAdjacentSide = sideAdjacent.getCompassFor(sideRotating);
		if(whichPieceFace == 1) //Edge Piece Faces
		{
			ret = compassForAdjacentSide;
		} else if(whichPieceFace == 0) //Leading Corner Piece Faces
		{
			switch(compassForAdjacentSide)
			{
			case 1:
				ret = 0;
				break;
			case 5:
				ret = 2;
				break;
			case 7:
				ret = 8;
				break;
			case 3:
				ret = 6;
				break;
			}
		} else if(whichPieceFace == 2) //Following Corner Piece Faces
		{
			switch(compassForAdjacentSide)
			{
			case 1:
				ret = 2;
				break;
			case 5:
				ret = 8;
				break;
			case 7:
				ret = 6;
				break;
			case 3:
				ret = 0;
				break;
			}
		}
		return ret;
	}

	private void crossSidePieceFaceRotation(ArrayList<Integer> ring) 
	{
		int sideCodeA = ring.get(0) / 9;
		int itemCodeA = ring.get(0) % 9;
		
		int placeHolder = getSide(sideCodeA).getPieceFace(itemCodeA).getSideCode();

		for(int lop = 0; lop < ring.size(); lop++)
		{
			int replaceWith;
			if(lop < ring.size() - 1)
			{				
				int sideCodeB = ring.get(lop + 1) / 9;
				int itemCodeB = ring.get(lop + 1) % 9;
				replaceWith = getSide(sideCodeB).getPieceFace(itemCodeB).getSideCode();
			} else
			{
				replaceWith = placeHolder;
			}
			
			sideCodeA = ring.get(lop) / 9;
			itemCodeA = ring.get(lop) % 9;
			getSide(sideCodeA).getPieceFace(itemCodeA).setSideCode(replaceWith);
		}		
	}
	
	public void moveCounterClockwise(RubikCubeSide side) throws Exception {
		moveCounterClockwise(side, 1);
	}
	
	public void moveCounterClockwise(RubikCubeSide side, int count) throws Exception {
		moveCounterClockwise(side, count * 3, true);
	}
	
	void moveCounterClockwise(RubikCubeSide side, int count, boolean saveHistory) throws Exception {
		if(saveHistory)
		{
			history.addToHistory(side, -count);
		}
		moveClockwise(side, count * 3, false);
	}

	public void undoLastMoves(int i) throws Exception {
		history.undoLastMoves(i);
	}

	public void redoMoves(int i) throws Exception {
		history.redoMoves(i);
	}
	

	public RubikCubeEdge getEdgePieceByLocation(RubikCubeSide locationSide1, RubikCubeSide locationSide2)  
	{
		for(int lop = 0; lop < edges.size(); lop++)
		{
			if(edges.get(lop).getLocation1() == locationSide1
					&& edges.get(lop).getLocation2() == locationSide2
			|| edges.get(lop).getLocation1() == locationSide2
					&& edges.get(lop).getLocation2() == locationSide1)
			{
				return edges.get(lop);
			}
		}
		return null;
	}
	
	public RubikCubeCorner getCornerPieceByLocation(RubikCubeSide locationSide1, RubikCubeSide locationSide2,
			RubikCubeSide locationSide3) 
	{
		for(int lop = 0; lop < corners.size(); lop++)
		{
			if(corners.get(lop).doesLocationMatch(locationSide1, locationSide2, locationSide3))
			{
				return corners.get(lop);
			}
		}

		return null;
	}
	
	public RubikCubeEdge getEdgePieceByFace(RubikCubeSide side1, RubikCubeSide side2)
	{
		for(int lop = 0; lop < edges.size(); lop++)
		{
			if((edges.get(lop).getFace1() == side1 && edges.get(lop).getFace2() == side2)
			|| (edges.get(lop).getFace1() == side2 && edges.get(lop).getFace2() == side1))
			{
				return edges.get(lop);
			}
		}
		return null;
	}
}
