package com.asz.rubik;

import java.util.ArrayList;

public class RubikCubeEdge {

	private RubikCubeSide sideFace1;
	private RubikCubeSide sideFace2;
	private RubikCubeSide locationSide1; 
	private RubikCubeSide locationSide2;
	private RubikCube cube; 

	public RubikCubeEdge(RubikCube cube, RubikCubeSide sideFace1, RubikCubeSide sideFace2) 
	{
		this.cube = cube;
		this.sideFace1 = sideFace1;
		this.sideFace2 = sideFace2;
		locationSide1 = sideFace1;
		locationSide2 = sideFace2;
	}
	
	public RubikCubeSide getFace1() {
		return sideFace1;
	}
	
	public RubikCubeSide getFace2() {
		return sideFace2;
	}
	
	public RubikCubeSide getLocation1()
	{
		return locationSide1;
	}

	public RubikCubeSide getLocation2()
	{
		return locationSide2;
	}
	
	public void setLocation(RubikCubeSide locationSide1, RubikCubeSide locationSide2) 
	{
		this.locationSide1 = locationSide1;
		this.locationSide2 = locationSide2;
	}

	public RubikCubeSide getFaceOn(RubikCubeSide side) 
	{
		RubikCubeSide ret;
		if(side == locationSide1)
		{
			ret = getFace1();
		} else if(side == locationSide2) 
		{
			ret = getFace2();
		} else
		{
			ret = null;
		}
		
		return ret;
	}
}
